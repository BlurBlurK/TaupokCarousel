﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using contentViewTest.SKEventHandler;
using SkiaSharp;
using SkiaSharp.Views.Forms;
using TouchTracking;
using Xamarin.Forms;

namespace contentViewTest
{
    public partial class MainPage4 : ContentPage
    {
        #region Declaration of test variables

        private bool IsShifted = false;

        #endregion

        #region Declaration of variables

        List<CarouselFrame> FrameList = new List<CarouselFrame>();

        List<String> ListOfEssayDetails = new List<string>();

        /*Definition of Carousel Bounds*/
        double _carouselViewRightBound = 404.0;

        double _carouselViewLeftBound = 0.0;
        double _topImgMidPt;

        /*touch detection variables*/
        SKPoint _prevPoint;

        SKPoint _deltaPoint;
        double _previousDelta;
        bool _directionHasChanged;
        double _sensitivity = 0.5;

        /*Timer related variables*/
        private int defaultplayInterval = 4;

        private CancellationTokenSource cancellation;
        TimeSpan playinterval = new TimeSpan(0, 0, 1);

        /*Flags*/
        private bool _screenWasPressed;

        private bool _hasPopulatedList;

        /*Variables related to properties*/
        private int _currentImageIdx;

        private int PreviousCurrentImageId = 0;
        private int _currentFrameIdx;
        private int PreviousCurrentFrameIdx = 0;

        #endregion

        #region Declaration of properties

        private int CurrentImageId
        {
            get { return _currentImageIdx; }
            set
            {
                PreviousCurrentImageId = _currentImageIdx;
                if (_currentImageIdx != value)
                {
                    _currentImageIdx = value;
                }

                if (_currentImageIdx < 0)
                {
                    _currentImageIdx = 0;
                }

                if (_currentImageIdx > ListOfEssayDetails.Count - 1)
                {
                    _currentImageIdx = ListOfEssayDetails.Count - 1;
                }
            }
        }

        public int CurrentFrameIdx
        {
            get { return _currentFrameIdx; }
            set
            {
                PreviousCurrentFrameIdx = _currentFrameIdx;
                if (_currentFrameIdx != value)
                {
                    _currentFrameIdx = value;
                }
            }
        }

        #endregion

        void initSourceData()
        {
            ListOfEssayDetails.Add("docomo.jpg");
            ListOfEssayDetails.Add("bottle.jpg");
            ListOfEssayDetails.Add("docomo.jpg");
            ListOfEssayDetails.Add("bottle.jpg");
            ListOfEssayDetails.Add("docomo.jpg");

            ListOfEssayDetails.Add("bottle.jpg");
            ListOfEssayDetails.Add("docomo.jpg");
            ListOfEssayDetails.Add("bottle.jpg");
            ListOfEssayDetails.Add("docomo.jpg");
            ListOfEssayDetails.Add("bottle.jpg");

            ListOfEssayDetails.Add("docomo.jpg");
            ListOfEssayDetails.Add("bottle.jpg");
            ListOfEssayDetails.Add("docomo.jpg");
            ListOfEssayDetails.Add("bottle.jpg");
            ListOfEssayDetails.Add("docomo.jpg");
        }


    public MainPage4()
        {
            InitializeComponent();
            
            VariableInitializations();

            initSourceData();

            Initialize7Frames();
        }

        private void VariableInitializations()
        {
            _prevPoint.X = 0;
            _topImgMidPt = _carouselViewRightBound * 0.5;
            _previousDelta = 0;
            _directionHasChanged = false;
            _hasPopulatedList = false;
            this.cancellation = new CancellationTokenSource();
            playinterval = new TimeSpan(0, 0, defaultplayInterval);
            _screenWasPressed = false;
            IsShifted = false;
        }

       
        void Initialize7Frames()
        {
            FrameList.Clear();

            for (int idx = 0; idx < ListOfEssayDetails.Count && idx < 7; idx++)
            {
                FrameList.Add(new CarouselFrame(ListOfEssayDetails[idx]));
                FrameList[idx].ContentView.BackgroundColor = ReturnFrameColor(idx);
                FrameList[idx].FrameImage.BackgroundColor = ReturnFrameColor(idx);

                PlaceFrameOnScreen(idx);
            }
            if (FrameList.Count > 0) ReorderFrames();
            TheRelativeLayout.RaiseChild(GridLayout);
        }

        string PrintColorNames(Color BckgrdColor)
        {
            string ColorName = "null";

            if (BckgrdColor == Color.Brown)
            {
                ColorName = "Brown";
            }
            if (BckgrdColor == Color.Red)
            {
                ColorName = "Red";
            }
            if (BckgrdColor == Color.Blue)
            {
                ColorName = "Blue";
            }
            if (BckgrdColor == Color.Green)
            {
                ColorName = "Green";
            }
            if (BckgrdColor == Color.Pink)
            {
                ColorName = "Pink";
            }
            if (BckgrdColor == Color.Yellow)
            {
                ColorName = "Yellow";
            }
            if (BckgrdColor == Color.Gray)
            {
                ColorName = "Gray";
            }


            return ColorName;
        }

        void ReorderFrames()
        {
            if (FrameList.Count > 0)
            {
                for (int i = 0; i < CurrentFrameIdx; i++)
                {
                    TheRelativeLayout.RaiseChild(FrameList[i].ContentView);
                    //    Debug.WriteLine("Raise Frame " + i + ", " + PrintColorNames(FrameList[i].FrameContentView.BackgroundColor));
                }

                for (int i = FrameList.Count - 1; i > CurrentFrameIdx; i--)
                {
                    TheRelativeLayout.RaiseChild(FrameList[i].ContentView);
                    //  Debug.WriteLine("Raise Frame " + i + ", " + PrintColorNames(FrameList[i].FrameContentView.BackgroundColor));
                }

                TheRelativeLayout.RaiseChild(FrameList[CurrentFrameIdx].ContentView);
                //  Debug.WriteLine("Raise Frame " + 3 + ", " + PrintColorNames(FrameList[3].FrameContentView.BackgroundColor));
            }
        }

        Color ReturnFrameColor(int FrameIdx)
        {
            switch (FrameIdx)
            {
                case 0:
                    return Color.Red;
                    break;
                case 1:
                    return Color.Blue;
                    break;
                case 2:
                    return Color.Green;
                    break;
                case 3:
                    return Color.Yellow;
                    break;
                case 4:
                    return Color.Brown;
                    break;
                case 5:
                    return Color.Pink;
                    break;
                case 6:
                    return Color.Gray;
                    break;

                default:
                    return Color.Black;
                    break;
            }
        }

        void PlaceFrameOnScreen(int FrameIdx)
        {
            if (FrameList != null && FrameList.Count > 0)
            {
                TheRelativeLayout.Children.Add(FrameList[FrameIdx].ContentView,
                    Constraint.RelativeToParent((parent) =>
                    {
                        if (FrameIdx < CurrentFrameIdx) FrameList[FrameIdx].FramePosX = 0; //Position of Left Frame View
                        else if (FrameIdx == CurrentFrameIdx)
                            FrameList[FrameIdx].FramePosX = 100; //Position of Middle Frame View
                        else
                            FrameList[FrameIdx].FramePosX =
                                _carouselViewRightBound * 0.5; //Position of Right Frame View
                        return FrameList[FrameIdx].FramePosX;
                    }),
                    Constraint.RelativeToParent((parent) =>
                    {
                        FrameList[FrameIdx].FramePosY = parent.Height * 0.1;
                        return parent.Height * 0.1;
                    }),
                    Constraint.Constant(FrameList[FrameIdx].FrameWidth),
                    Constraint.Constant(FrameList[FrameIdx].FrameHeight)
                );
                FrameList[FrameIdx].FrameImage.WidthRequest = FrameList[FrameIdx].FrameWidth;
                FrameList[FrameIdx].FrameImage.HeightRequest = FrameList[FrameIdx].FrameHeight;
            }
            TheRelativeLayout.RaiseChild(GridLayout);

        }
   
        void ReorderAllImg()
        {
            for (int idx = 0; idx < CurrentFrameIdx; idx++)
            {
                TheRelativeLayout.RaiseChild(FrameList[idx].ContentView);
            }

            for (int idx = FrameList.Count - 1; idx > CurrentFrameIdx; idx--)
            {
                TheRelativeLayout.RaiseChild(FrameList[idx].ContentView);
            }

            TheRelativeLayout.RaiseChild(FrameList[CurrentFrameIdx].ContentView);
        }

        public void RemoveAllFrames()
        {
            if (TheRelativeLayout != null)
            {
                foreach (var FrameItem in FrameList)
                {
                    if (TheRelativeLayout.Children.Contains(FrameItem.ContentView))
                    {
                        TheRelativeLayout.Children.Remove(FrameItem.ContentView);
                    }
                 }
                FrameList.Clear();
            }
        }
        void RedrawLayout()
        {
            if (FrameList != null && FrameList.Count > 0)
            {
                int _tempIdx = 0;
                foreach (var ImageFrameItem in FrameList)
                {
                    int _IDX = _tempIdx;

                    TheRelativeLayout.Children.Add(FrameList[_IDX].ContentView,
                        Constraint.RelativeToParent((parent) =>
                        {
                            int _idxholder = _tempIdx;
                            if (_IDX < CurrentFrameIdx) FrameList[_IDX].FramePosX = 0; //Position of Left Frame View
                            else if (_IDX == CurrentFrameIdx)
                                FrameList[_IDX].FramePosX = 100; //Position of Middle Frame View
                            else
                                FrameList[_IDX].FramePosX =
                                    _carouselViewRightBound * 0.5; //Position of Right Frame View
                            return FrameList[_IDX].FramePosX;
                        }),
                        Constraint.RelativeToParent((parent) =>
                        {
                            FrameList[_IDX].FramePosY = parent.Height * 0.1;
                            return parent.Height * 0.1;
                        }),
                        Constraint.Constant(FrameList[_IDX].FrameWidth),
                        Constraint.Constant(FrameList[_IDX].FrameHeight)
                    );
                    FrameList[_IDX].FrameImage.WidthRequest = FrameList[_IDX].FrameWidth;
                    FrameList[_IDX].FrameImage.HeightRequest = FrameList[_IDX].FrameHeight;

                    _tempIdx++;
                }

                if (CurrentFrameIdx < FrameList.Count) TheRelativeLayout.RaiseChild(FrameList[CurrentFrameIdx].ContentView);
            }
            TheRelativeLayout.RaiseChild(GridLayout);
        }

        void CapTranslationXValue(int frameIdx)
        {
            if ((FrameList[frameIdx].FramePosX + FrameList[frameIdx].XTranslation + FrameList[frameIdx].FrameImage.Width) > _carouselViewRightBound)
            {
                FrameList[frameIdx].XTranslation = _carouselViewRightBound - FrameList[frameIdx].FramePosX - FrameList[frameIdx].FrameImage.Width;
            }
            else if ((FrameList[frameIdx].FramePosX + FrameList[frameIdx].XTranslation) < _carouselViewLeftBound)
            {
                FrameList[frameIdx].XTranslation = _carouselViewLeftBound - FrameList[frameIdx].FramePosX;
            }
        }

        void MakeTopImgCentered()
        {
            double _tempUntranslateValue;
            int _tempIdx = 0;

            /*Translate top image back to the center of the view*/
            _tempUntranslateValue = _topImgMidPt - FrameList[CurrentFrameIdx].XTranslation - FrameList[CurrentFrameIdx].FramePosX - FrameList[CurrentFrameIdx].FrameWidth * 0.5;
            FrameList[CurrentFrameIdx].XTranslation = FrameList[CurrentFrameIdx].XTranslation + _tempUntranslateValue;
            FrameList[CurrentFrameIdx].ContentView.TranslateTo(FrameList[CurrentFrameIdx].XTranslation, 0);

            /*Translate images back to where they are supposed to be*/
            if (_tempUntranslateValue > 0)
            {
                //Need to move image right as image was originally from the right
                if (CurrentFrameIdx < (FrameList.Count - 1))
                {
                    FrameList[CurrentFrameIdx + 1].XTranslation = FrameList[CurrentFrameIdx + 1].XTranslation + _tempUntranslateValue;
                }
            }
            else if (_tempUntranslateValue < 0)
            {
                //Need to move image left as image was originally from the left
                if (CurrentFrameIdx > 0)
                {
                    FrameList[CurrentFrameIdx - 1].XTranslation = FrameList[CurrentFrameIdx - 1].XTranslation + _tempUntranslateValue;
                }
            }

            /*Confine images to the sides if they are not on top*/
            foreach (var ImgFrame in FrameList)
            {
                if (_tempIdx != CurrentFrameIdx)
                {
                    if ((FrameList[_tempIdx].XTranslation + FrameList[_tempIdx].FramePosX + FrameList[_tempIdx].FrameWidth * 0.5) < _topImgMidPt)
                    {
                        FrameList[_tempIdx].XTranslation = 0 - FrameList[_tempIdx].FramePosX;
                    }
                    else
                    {
                        FrameList[_tempIdx].XTranslation = _carouselViewRightBound * 0.5 - FrameList[_tempIdx].FramePosX;
                    }
                    FrameList[_tempIdx].ContentView.TranslateTo(FrameList[_tempIdx].XTranslation, 0);
                }
                _tempIdx++;
            }
        }

        void OnTouchEffectAction(object sender, TouchActionEventArgs args)
        {
            // Convert Xamarin.Forms point to pixels
            Point pt = args.Location;
            SKPoint point =
                new SKPoint((float)(canvasView.CanvasSize.Width * pt.X / canvasView.Width),
                    (float)(canvasView.CanvasSize.Height * pt.Y / canvasView.Height));

            if (FrameList.Count() > 0)
            {
                switch (args.Type)
                {
                    case TouchActionType.Pressed:
                       Debug.WriteLine("Press detected!");
                        _prevPoint.X = (float)pt.X;
                        _screenWasPressed = true;
                        break;

                    case TouchActionType.Moved:
                          Debug.WriteLine("Move detected!");
                        if (_screenWasPressed )//&& !IsShifted)
                        {
                            _deltaPoint.X = (float)(pt.X - _prevPoint.X) * (float)_sensitivity;
                            // _deltaPoint.X = (float) ((float)(pt.X - _prevPoint.X) *(float)_sensitivity *  (pt.X - _prevPoint.X) * _sensitivity);

                            /*Move images back to where they are supposed to be once the finger motion has changed direction*/
                            if ((_deltaPoint.X > 0 && _previousDelta < 0) ||
                                (_deltaPoint.X < 0 && _previousDelta > 0))
                            {
                                _directionHasChanged = true;
                            }
                            else
                            {
                                _directionHasChanged = false;
                                ;
                            }
                            if (_directionHasChanged)
                            {
                                MakeTopImgCentered();
                            }

                            /*Translate the image on top*/
                            FrameList[CurrentFrameIdx].XTranslation =
                                (float)(_deltaPoint.X + FrameList[CurrentFrameIdx].XTranslation);
                            CapTranslationXValue(
                                CurrentFrameIdx); //Cap values to ensure that they are within range of the view
                            FrameList[CurrentFrameIdx].ContentView
                                .TranslateTo(FrameList[CurrentFrameIdx].XTranslation, 0);

                            /*Translate the images next to the top image*/
                            TranslateSelectedImg(_deltaPoint.X);
                            DetermineTopImg3(_deltaPoint.X);

                            /*Save values*/
                            _prevPoint.X = (float)pt.X;
                            _previousDelta = _deltaPoint.X;

                            //Reset value
                            _deltaPoint.X = 0;
                        }
                        break;

                    case TouchActionType.Released:

                    case TouchActionType.Cancelled:
                        

                        //Set Defaults
                        _directionHasChanged = false;
                        _previousDelta = 0;
                        _screenWasPressed = false;

                        /*Move images back to where they are supposed to be once the finger motion has stopped*/
                        //if(!IsShifted)
                            MakeTopImgCentered();
                        IsShifted = false;
                        Debug.WriteLine("Released or cancelled detected");
                        
                        break;
                }

            }
        }

        void TranslateFrame(double DeltaTranslation, int Idx)
        {
            FrameList[Idx].XTranslation = (float)(DeltaTranslation + FrameList[Idx].XTranslation);
            CapTranslationXValue(Idx);
            FrameList[Idx].ContentView.TranslateTo((FrameList[Idx].XTranslation), 0);
        }

        void TranslateSelectedImg(double DeltaTranslation)
        {
            if (CurrentFrameIdx > 0) TranslateFrame(DeltaTranslation, CurrentFrameIdx - 1);
            if (CurrentFrameIdx < FrameList.Count - 1) TranslateFrame(DeltaTranslation, CurrentFrameIdx + 1);
        }

        void TranslateAllImg(double DeltaTranslation)
        {
            int _tempIdx = 0;
            foreach (var ImgFrameItem in FrameList)
            {
                ImgFrameItem.XTranslation = ImgFrameItem.XTranslation + DeltaTranslation;
                CapTranslationXValue(_tempIdx);
                ImgFrameItem.ContentView.TranslateTo(ImgFrameItem.XTranslation, 0);
                _tempIdx++;
            }
        }

        void DetermineTopImg3(double DeltaTranslation)
        {

            int _tempIdx = 0;
            bool _TopImgExists = false;
            double _tempDifference;
            foreach (var ImgFrameItem in FrameList)
            {
                if ((FrameList[_tempIdx].XTranslation + FrameList[_tempIdx].FramePosX + (FrameList[_tempIdx].FrameWidth * 0.3)) <= _topImgMidPt
                    && _topImgMidPt < (FrameList[_tempIdx].XTranslation + FrameList[_tempIdx].FramePosX + (FrameList[_tempIdx].FrameWidth * 0.9)))
                {
                    CurrentImageId = CurrentImageId + (_tempIdx - CurrentFrameIdx);
                    CurrentFrameIdx = _tempIdx;
                    _TopImgExists = true;
                    TheRelativeLayout.RaiseChild(FrameList[CurrentFrameIdx].ContentView);
                    TheRelativeLayout.RaiseChild(GridLayout);

                }
                _tempIdx++;
            }


            if (!_TopImgExists)
            {
                if (DeltaTranslation > 0)
                {
                    if (CurrentFrameIdx > 0)
                    {
                        _tempDifference = (FrameList[CurrentFrameIdx - 1].XTranslation + FrameList[CurrentFrameIdx - 1].FramePosX) -
                                          (FrameList[CurrentFrameIdx].XTranslation + FrameList[CurrentFrameIdx].FramePosX);

                        if (_tempDifference >= 0)
                        {
                            TranslateFrame(_tempDifference, CurrentFrameIdx);
                            TranslateFrame(-_tempDifference, CurrentFrameIdx - 1);
                            CurrentFrameIdx = CurrentFrameIdx - 1;
                            CurrentImageId = CurrentImageId - 1;
                        }
                    }
                }
                else
                {
                    if (CurrentFrameIdx < FrameList.Count - 1)
                    {
                        _tempDifference = (FrameList[CurrentFrameIdx + 1].XTranslation + FrameList[CurrentFrameIdx + 1].FramePosX + (FrameList[CurrentFrameIdx + 1].FrameWidth * 0.5))
                                          - (FrameList[CurrentFrameIdx].XTranslation + FrameList[CurrentFrameIdx].FramePosX + (FrameList[CurrentFrameIdx].FrameWidth * 0.5));

                        if (_tempDifference <= 0)
                        {
                            TranslateFrame(_tempDifference, CurrentFrameIdx);
                            TranslateFrame(-_tempDifference, CurrentFrameIdx + 1);
                            CurrentFrameIdx = CurrentFrameIdx + 1;
                            CurrentImageId = CurrentImageId + 1;
                        }
                    }
                }
            }
            //      CurrentImageId = CurrentImageId + (CurrentFrameIdx - PreviousCurrentFrameIdx);
  
            if (CurrentFrameIdx < PreviousCurrentFrameIdx)
            {
                ShiftLastFrameToFirst();
            }
            else if (CurrentFrameIdx > PreviousCurrentFrameIdx)
            {
                ShiftFirstFrameToLast();
            }
            TheRelativeLayout.RaiseChild(FrameList[CurrentFrameIdx].ContentView);
            TheRelativeLayout.RaiseChild(GridLayout);
        }
 
        private void ShiftLastFrameToFirst()
        {
            if (CurrentImageId > 0)
            {

                if (0 <= CurrentImageId - 3 && CurrentFrameIdx < FrameList.Count - 4)
                {
                    CarouselFrame tempContentViewHolder = FrameList[FrameList.Count - 1];

                    FrameList.Remove(FrameList[FrameList.Count - 1]);
                    FrameList.Insert(0, tempContentViewHolder);
                    FrameList[0].XTranslation =
                        _carouselViewLeftBound - FrameList[0].FramePosX;
                    CapTranslationXValue(0);
                    TheRelativeLayout.LowerChild(FrameList[0].ContentView);
                     
                     FrameList[0].ImageSource = ListOfEssayDetails[CurrentImageId - 3];
                    

                    FrameList[0].ContentView
                        .TranslateTo(FrameList[0].XTranslation, 0);

                    CurrentFrameIdx = CurrentFrameIdx + 1;
                }


                //ReorderFrames();
            }
        }

        private void ShiftFirstFrameToLast()
        {
            if (CurrentImageId < (ListOfEssayDetails.Count - 1))
            {

                if (CurrentImageId + 3 <= ListOfEssayDetails.Count - 1 && CurrentFrameIdx > 3)
                {
                    FrameList.Add(FrameList[0]);
                    FrameList.Remove(FrameList[0]);

                    FrameList[FrameList.Count - 1].XTranslation = 203 - FrameList[FrameList.Count - 1].FramePosX;
                    CapTranslationXValue(FrameList.Count - 1);
                    //FrameList[FrameList.Count - 1].ContentView.IsVisible = false;
                    // FrameList[FrameList.Count - 1].ContentView.IsVisible = true;
                    TheRelativeLayout.LowerChild(FrameList[FrameList.Count - 1].ContentView);
                     FrameList[FrameList.Count - 1].ContentView.TranslateTo(FrameList[FrameList.Count - 1].XTranslation, 0);
                      FrameList[FrameList.Count - 1].ImageSource = "bear.png";
                    //   FrameList[FrameList.Count - 1].FrameImage.Source = ImageSource.FromFile("bear.png");
                    TheRelativeLayout.LowerChild(FrameList[FrameList.Count - 1].ContentView);

                    IsShifted = true;
                    CurrentFrameIdx = CurrentFrameIdx - 1;
                }
                  ReorderFrames();
            }
        }

        void OnCanvasViewPaintSurface(object sender, SKPaintSurfaceEventArgs args)
        {
            SKCanvas canvas = args.Surface.Canvas;
            canvas.Clear();
            
        }
    }
}
