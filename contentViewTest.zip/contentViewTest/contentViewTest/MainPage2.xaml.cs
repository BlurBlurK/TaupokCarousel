﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace contentViewTest
{
    public partial class MainPage2 : ContentPage
    {
        List<CarouselFrame> FrameList = new List<CarouselFrame>();
        public MainPage2()
        {
            InitializeComponent();

            FrameList.Add(new CarouselFrame("icon.png"));
            FrameList.Add(new CarouselFrame("icon.png"));

            int CurrentFrameIdx = 0;
             
            for(int FrameIdx = 0; FrameIdx<FrameList.Count;FrameIdx++)
            {
                FrameList[0].ContentView.BackgroundColor=Color.AliceBlue;
                FrameList[1].ContentView.BackgroundColor = Color.Red;
                int idx = FrameIdx; int idxx = FrameIdx;
                MainLayout.Children.Add(FrameList[FrameIdx].ContentView,
                    Constraint.RelativeToParent((parent) =>
                    {
                       
                        if (FrameIdx < CurrentFrameIdx)
                            FrameList[idxx].FramePosX = 0; //Position of Left Frame View
                        else if (idxx == CurrentFrameIdx)
                            FrameList[idxx].FramePosX = 100; //Position of Middle Frame View
                        else
                            FrameList[idxx].FramePosX =
                                400 * 0.5; //Position of Right Frame View
                        Debug.WriteLine("idxx is " + idxx);
                        return FrameList[idxx].FramePosX;
                    }),
                    Constraint.RelativeToParent((parent) =>
                    {
                        FrameList[idxx].FramePosY = parent.Height * 0.1;
                        return parent.Height * 0.1;
                    }),
                    Constraint.Constant(FrameList[FrameIdx].FrameWidth),
                    Constraint.Constant(FrameList[FrameIdx].FrameHeight)
                );
                FrameList[FrameIdx].FrameImage.WidthRequest = FrameList[FrameIdx].FrameWidth;
                FrameList[FrameIdx].FrameImage.HeightRequest = FrameList[FrameIdx].FrameHeight;
            }
            //ContentView1.TranslationX = 100;
            //ContentView1.TranslateTo(ContentView1.TranslationX, 0);
        }

        private void ChangeSrc_OnClicked(object sender, EventArgs e)
        {
          FrameList[0].ImageSource = "bear.jpg";
        }

        private void TranslateImg_OnClicked(object sender, EventArgs e)
        {
            FrameList[0].ContentView.TranslationX = 200;
            FrameList[0].ContentView.TranslateTo(FrameList[0].ContentView.TranslationX, 0);
        }

        private void UnTranslateImg_OnClicked(object sender, EventArgs e)
        {
            FrameList[0].ContentView.TranslationX = 0;
            FrameList[0].ContentView.TranslateTo(FrameList[0].ContentView.TranslationX, 0);
        }

        private void UnChangeSrc_OnClicked(object sender, EventArgs e)
        {
            FrameList[0].ImageSource = "icon.png";
        }
    }
}
