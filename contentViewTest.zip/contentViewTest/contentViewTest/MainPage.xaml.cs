﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace contentViewTest
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();

            ContentView1.TranslationX = 100;
            ContentView1.TranslateTo(ContentView1.TranslationX, 0);
        }

        private void ChangeSrc_OnClicked(object sender, EventArgs e)
        {
           Image1.Source = ImageSource.FromFile("bear.jpg");
        }
    }
}
