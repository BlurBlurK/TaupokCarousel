﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace contentViewTest
{
    public class CarouselFrame
    {
        private string _imageSource;

        public string ImageSource
        {

            get { return _imageSource; }
            set
            {
                _imageSource = value;
                  FrameImage.Source = Xamarin.Forms.ImageSource.FromFile(ImageSource); 
            }
        } 

        public double XTranslation { get; set; }
        public double FramePosX { get; set; }
        public double FramePosY { get; set; }
        public double FrameHeight { get; set; }
        public double FrameWidth { get; set; }

        public ContentView ContentView { get; }

        public CarouselFrame(string imgsrc)
        {
            ContentView = new ContentView { Content = FrameImage };
            ImageSource = imgsrc;
            FrameImage.HeightRequest = 200;
            FrameImage.WidthRequest = 200;
            //FrameImage.IsEnabled = false;
            //ContentView.IsEnabled = false;
            ContentView.HeightRequest = 200;
            ContentView.WidthRequest = 200;
               FrameImage.BackgroundColor = Color.DimGray;
            //  ContentView.BackgroundColor = Color.Aquamarine;
            FramePosX = 0;
            FramePosY = 0;
            FrameHeight = 200;
            FrameWidth = 200;
            XTranslation = 0;
        }

        public Image FrameImage { get; set; } = new Image();
    }
}
